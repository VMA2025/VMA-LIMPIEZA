import { useState, useEffect } from 'react';
import { auth, db } from './firebase';
import { onAuthStateChanged, signOut } from 'firebase/auth';
import Auth from './components/Auth';
import TaskList from './components/TaskList';
import Reporte from './components/Reporte';
import AdminPanel from './components/AdminPanel';
import { doc, getDoc } from 'firebase/firestore';

function App() {
  const [user, setUser] = useState(null);
  const [role, setRole] = useState('');
  const [view, setView] = useState('main');

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async (user) => {
      setUser(user);
      if (user) {
        const userDoc = await getDoc(doc(db, 'usuarios', user.uid));
        if (userDoc.exists()) {
          setRole(userDoc.data().rol);
        }
      }
    });
    return () => unsub();
  }, []);

  const renderContent = () => {
    if (role === 'supervisor') {
      if (view === 'admin') return <AdminPanel />;
      if (view === 'reporte') return <Reporte />;
      return (
        <div>
          <div className="flex gap-4 mb-4">
            <button className="bg-gray-200 px-4 py-2" onClick={() => setView('reporte')}>Ver Reportes</button>
            <button className="bg-gray-200 px-4 py-2" onClick={() => setView('admin')}>Panel Admin</button>
          </div>
          <Reporte />
        </div>
      );
    }
    return <TaskList user={user} />;
  };

  return (
    <div className="p-4">
      {user ? (
        <div>
          <div className="flex justify-between items-center">
            <h1 className="text-xl font-bold">Bienvenido, {user.email}</h1>
            <button onClick={() => signOut(auth)} className="text-red-500">Cerrar sesión</button>
          </div>
          {renderContent()}
        </div>
      ) : (
        <Auth />
      )}
    </div>
  );
}

export default App;