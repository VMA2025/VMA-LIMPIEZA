import { useEffect, useState } from 'react';
import { db } from '../firebase';
import { collection, getDocs, doc, updateDoc, addDoc } from 'firebase/firestore';

function AdminPanel() {
  const [usuarios, setUsuarios] = useState([]);
  const [descripcion, setDescripcion] = useState('');
  const [zona, setZona] = useState('');
  const [fecha, setFecha] = useState('');
  const [asignadoA, setAsignadoA] = useState('');

  useEffect(() => {
    const fetchUsers = async () => {
      const querySnapshot = await getDocs(collection(db, 'usuarios'));
      const usersData = querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setUsuarios(usersData);
    };
    fetchUsers();
  }, []);

  const cambiarRol = async (id, nuevoRol) => {
    await updateDoc(doc(db, 'usuarios', id), { rol: nuevoRol });
    setUsuarios(usuarios.map(u => u.id === id ? { ...u, rol: nuevoRol } : u));
  };

  const crearTarea = async () => {
    if (!descripcion || !zona || !fecha || !asignadoA) return;
    await addDoc(collection(db, 'tareas'), {
      descripcion,
      zona,
      fecha,
      asignadoA,
      completada: false,
      evidencia: ''
    });
    setDescripcion('');
    setZona('');
    setFecha('');
    setAsignadoA('');
    alert('Tarea creada y asignada');
  };

  return (
    <div className="mt-4 space-y-8">
      <div>
        <h2 className="text-lg font-bold mb-2">Usuarios</h2>
        {usuarios.map(user => (
          <div key={user.id} className="border p-2 flex justify-between">
            <span>{user.email} ({user.rol})</span>
            <button onClick={() => cambiarRol(user.id, user.rol === 'limpiador' ? 'supervisor' : 'limpiador')} className="text-blue-500">
              Cambiar a {user.rol === 'limpiador' ? 'supervisor' : 'limpiador'}
            </button>
          </div>
        ))}
      </div>

      <div>
        <h2 className="text-lg font-bold mb-2">Crear y asignar tarea</h2>
        <input value={descripcion} onChange={e => setDescripcion(e.target.value)} placeholder="Descripción" className="border p-2 mr-2" />
        <input value={zona} onChange={e => setZona(e.target.value)} placeholder="Zona" className="border p-2 mr-2" />
        <input value={fecha} onChange={e => setFecha(e.target.value)} placeholder="Fecha" className="border p-2 mr-2" />
        <select value={asignadoA} onChange={e => setAsignadoA(e.target.value)} className="border p-2 mr-2">
          <option value="">Asignar a...</option>
          {usuarios.map(user => (
            <option key={user.id} value={user.id}>{user.email}</option>
          ))}
        </select>
        <button onClick={crearTarea} className="bg-green-500 text-white px-4 py-2">Crear</button>
      </div>
    </div>
  );
}

export default AdminPanel;